# todo
List of todo activities


## 24-apr-2022
+ `2250` Tomorrow check whether the ans/102XXYYY/\*.ipynb works, since it was developed in different folder hierarchy.


## 25-apr-2022
+ `0322` Fix yesterday problem `..` --> `../..` in the last argument of `sys.path.insert()`.
