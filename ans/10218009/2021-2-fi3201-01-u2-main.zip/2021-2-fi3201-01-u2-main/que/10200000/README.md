# que
questions to be answered by [Your Full Name](https://github.com/username)


## progress
No | Question | Answer
:-: | :- | :-:
1 | [hello_student](hello_student.ipynb) | :x:
2 | [triangle_text_art](triangle_text_art.ipynb) | :x:
3 | [draw_shapes](draw_shapes.ipynb) | :x:
4 | [draw_flowchart](draw_flowchart.ipynb) | :x:
5 | [list_min_max_avg](list_min_max_avg.ipynb) | :x:
6 | [draw_polygon](draw_polygon.ipynb) | :x:

## instruction
1. Edit `Your Full Name` with your full name and related link to your GitHub username `https://github.com/username`.
2. After you answer a question, please update its status from :x: to :heavy_check_mark:.
