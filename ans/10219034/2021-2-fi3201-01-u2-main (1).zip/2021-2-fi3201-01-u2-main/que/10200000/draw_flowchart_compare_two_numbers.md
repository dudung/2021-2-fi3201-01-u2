![](draw_flowchart_compare_two_numbers.png)

```mermaid
%%mermaid_magic -h 160

flowchart TD
  B([ Mulai ]);
  E([ Selesai ]);
  B --> E;
```